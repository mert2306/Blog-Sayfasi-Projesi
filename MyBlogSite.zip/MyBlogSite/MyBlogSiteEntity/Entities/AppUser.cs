﻿using Microsoft.AspNetCore.Identity;
using MyBlogSite.Core.Entities;

namespace MyBlogSite.Entity.Entities
{
    public class AppUser : IdentityUser<Guid>, IEntityBase
    {
        public string Firstname { get; set; }
        public string LastName { get; set; }

        public Guid ImageId { get; set; } = Guid.Parse("56910397-a84a-4d53-af36-b31abde1da55");
        public Image Image { get; set; }

        public ICollection<Article> Articles { get; set; }
    }
}
