﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Entity.Enums
{
    public enum ImageType
    {
        User = 0,
        Post = 1,

    }
}
