﻿using MyBlogSite.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Entity.Viewmodels.Users
{
    public class UserAddViewModel
    {
        public Guid RoleId { get; set; }
        public string Firstname { get; set; }
        public string LastName { get; set; }

        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string Password { get; set; }
        public List<AppRole> Roles { get; set; }
    }
}
