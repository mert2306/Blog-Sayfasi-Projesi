﻿using Microsoft.AspNetCore.Http;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Entity.Viewmodels.Users
{
    public class UserProfileViewModel
    {
        public string Firstname { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public string CurrentPassword { get; set; }
        public string? NewPassword { get; set; }
        public IFormFile? Photo { get; set; }
        public Image Image { get; set; }

    }
}
