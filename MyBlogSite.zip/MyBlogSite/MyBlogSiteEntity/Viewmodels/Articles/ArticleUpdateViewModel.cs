﻿using Microsoft.AspNetCore.Http;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Categories;

namespace MyBlogSite.Entity.Viewmodels.Articles
{
    public class ArticleUpdateViewModel
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public Guid CategoryId { get; set; }
        
        public Image Image { get; set; }

        public IFormFile? Photo { get; set; }

        public IList<CategoryViewModel> Categories { get; set; }
    }
}
