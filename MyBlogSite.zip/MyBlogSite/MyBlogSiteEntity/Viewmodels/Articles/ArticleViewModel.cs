﻿using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Categories;

namespace MyBlogSite.Entity.Viewmodels.Articles
{
    public class ArticleViewModel
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Content { get; set; }
        public CategoryViewModel Category { get; set; }

        public DateTime CraetedDate { get; set; } = DateTime.Now;

        public Image Image { get; set; }

        public AppUser User { get; set; }

        public string CreatedBy { get; set; }

        public bool IsDeleted { get; set; }
        public int ViewCount { get; set; }

    }
}
