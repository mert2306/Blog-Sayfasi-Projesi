﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MyBlogSite.Data.Context;
using MyBlogSite.Data.Repositories.Abstractions;
using MyBlogSite.Data.Repositories.Concretes;
using MyBlogSite.Data.UnitOfWorks;

namespace MyBlogSite.Data.Extensions
{
    public static class DataLayerExtension
    {
        public static IServiceCollection LoadDataLayerExtension(this IServiceCollection services, IConfiguration config)
        {
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddDbContext<AppDbContext>(opt => opt.UseSqlServer(config.GetConnectionString("DefaultConnetion")));
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            return services;
        }

    }
}
