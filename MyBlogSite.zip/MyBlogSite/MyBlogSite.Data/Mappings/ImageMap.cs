﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Data.Mappings
{
    public class ImageMap : IEntityTypeConfiguration<Image>
    {
        public void Configure(EntityTypeBuilder<Image> builder)
        {
            builder.HasData(
                new Image
                {
                    Id = Guid.Parse("56910397-A84A-4D53-AF36-B31ABDE1DA55"),
                    FileName = "Images/testImages",
                    FileType = "jpg",
                    CreatedBy = "Admin Test",
                    CreatedDate = DateTime.Now,
                    IsDeleted = false,
                },
               new Image
               {
                   Id = Guid.Parse("77E2D3F6-B7BF-4549-B7E2-7673D57586D6"),
                   FileName = "Images/AsiltestImages",
                   FileType = "png",
                   CreatedBy = "Admin Test",
                   CreatedDate = DateTime.Now,
                   IsDeleted = false,

               });
                
        }
    }
}
