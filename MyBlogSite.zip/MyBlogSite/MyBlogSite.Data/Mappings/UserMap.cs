﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Data.Mappings
{
    public class UserMap : IEntityTypeConfiguration<AppUser>
    {
        public void Configure(EntityTypeBuilder<AppUser> builder)
        {
            builder.HasKey(u => u.Id);


            builder.HasIndex(u => u.NormalizedUserName).HasName("UserNameIndex").IsUnique();
            builder.HasIndex(u => u.NormalizedEmail).HasName("EmailIndex");


            builder.ToTable("Users");

            builder.Property(u => u.ConcurrencyStamp).IsConcurrencyToken();

            builder.Property(u => u.UserName).HasMaxLength(100);
            builder.Property(u => u.NormalizedUserName).HasMaxLength(256);
            builder.Property(u => u.Email).HasMaxLength(100);
            builder.Property(u => u.NormalizedEmail).HasMaxLength(256);


            builder.HasMany<AppUserClaim>().WithOne().HasForeignKey(uc => uc.UserId).IsRequired();

            builder.HasMany<AppUserLogin>().WithOne().HasForeignKey(ul => ul.UserId).IsRequired();

            builder.HasMany<AppUserToken>().WithOne().HasForeignKey(ut => ut.UserId).IsRequired();

            builder.HasMany<AppUserRole>().WithOne().HasForeignKey(ur => ur.UserId).IsRequired();



            var superadmin = new AppUser
            {
                Id = Guid.Parse("4BF2F8D0-F80F-488C-9C70-290D91E06DCC"),
                UserName = "superadmin@gmail.com",
                NormalizedUserName = "SUPERADMIN@GMAIL.COM",
                Email = "superadmin@gmail.com",
                NormalizedEmail = "SUPERADMIN@GMAIL.COM",
                PhoneNumber = "+905545605936",
                Firstname = "Mertcan",
                LastName = "Asıl",
                PhoneNumberConfirmed = true,
                EmailConfirmed = true,
                SecurityStamp = Guid.NewGuid().ToString(),
                ImageId = Guid.Parse("56910397-A84A-4D53-AF36-B31ABDE1DA55")
            };
            superadmin.PasswordHash = CreatPasswordHash(superadmin, "232323");

            var admin = new AppUser
            {
                Id = Guid.Parse("2862CE3E-63E2-480C-8F2A-1F58BADF318B"),
                UserName = "admin@gmail.com",
                NormalizedUserName = "ADMIN@GMAIL.COM",
                Email = "admin@gmail.com",
                NormalizedEmail = "ADMIN@GMAIL.COM",
                PhoneNumber = "+905373752289",
                Firstname = "Elif Deniz",
                LastName = "Özgen",
                PhoneNumberConfirmed = false,
                EmailConfirmed = false,
                SecurityStamp = Guid.NewGuid().ToString(),
                ImageId = Guid.Parse("77E2D3F6-B7BF-4549-B7E2-7673D57586D6")
            };
            admin.PasswordHash = CreatPasswordHash(admin, "272727");

            builder.HasData(superadmin, admin);
        }


        private string CreatPasswordHash(AppUser user, string password)
        {

            var passwordHaser = new PasswordHasher<AppUser>();
            return passwordHaser.HashPassword(user, password);
        }
    }
}
