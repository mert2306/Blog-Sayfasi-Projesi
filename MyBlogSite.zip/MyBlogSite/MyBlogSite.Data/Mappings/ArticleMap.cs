﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Data.Mappings
{
    public class ArticleMap : IEntityTypeConfiguration<Article>
    {
        public void Configure(EntityTypeBuilder<Article> builder)
        {
            builder.HasData(new Article
            {
                Id = Guid.NewGuid(),
                Title = "Mertcan Makale",
                Content = "Mertcan Deneme Makalesi Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                ViewCount = 15,
                CategoryId = Guid.Parse("1EAF4102-5606-44AB-B75C-888E20F57CC4"),
                ImageId = Guid.Parse("56910397-A84A-4D53-AF36-B31ABDE1DA55"),
                CreatedBy = "Mertcan Asil",
                CreatedDate = DateTime.Now,
                IsDeleted = false,
                UserId = Guid.Parse("4BF2F8D0-F80F-488C-9C70-290D91E06DCC")
            },
            new Article
            {
                Id = Guid.NewGuid(),
                Title = "Asil Makale",
                Content = "Asil Deneme Makalesi 2 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
                ViewCount = 15,
                CategoryId = Guid.Parse("98C6E945-F9E9-4141-A423-59FA1CBE51D3"),
                ImageId =  Guid.Parse("77E2D3F6-B7BF-4549-B7E2-7673D57586D6"),
                CreatedBy = "Kara Davut",
                CreatedDate = DateTime.Now,
                IsDeleted = false,
                UserId = Guid.Parse("2862CE3E-63E2-480C-8F2A-1F58BADF318B")
            });
        }
    }
}
