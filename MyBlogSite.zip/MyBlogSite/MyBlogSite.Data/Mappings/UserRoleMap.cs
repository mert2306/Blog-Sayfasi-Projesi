﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Data.Mappings
{
    public class UserRoleMap : IEntityTypeConfiguration<AppUserRole>
    {
        public void Configure(EntityTypeBuilder<AppUserRole> builder)
        {
            builder.HasKey(r => new { r.UserId, r.RoleId });

            builder.ToTable("UserRoles");

            builder.HasData(new AppUserRole
            {
                UserId = Guid.Parse("4BF2F8D0-F80F-488C-9C70-290D91E06DCC"),
                RoleId = Guid.Parse("81194495-C625-4D58-B5AB-68BC16276D12")
            },
            new AppUserRole
            {
                UserId = Guid.Parse("2862CE3E-63E2-480C-8F2A-1F58BADF318B"),
                RoleId = Guid.Parse("3B484B41-4E1B-4D7E-A4B6-0E914A926AF8")

            }
            );
        }
    }
}
