﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Data.Mappings
{
    public class CategoryMap : IEntityTypeConfiguration<Category>
    {
        public void Configure(EntityTypeBuilder<Category> builder)
        {
            builder.HasData(
                new Category
                {
                    Id = Guid.Parse("1EAF4102-5606-44AB-B75C-888E20F57CC4"),
                    Name = "Birinci Makale",
                    CreatedBy = "Mertcan Asil",
                    CreatedDate = DateTime.Now,
                    IsDeleted = false,
                },
                new Category
                {
                    Id = Guid.Parse("98C6E945-F9E9-4141-A423-59FA1CBE51D3"),
                    Name = "İkinci Makale",
                    CreatedBy = "Kara Davut",
                    CreatedDate = DateTime.Now,
                    IsDeleted = false,
                });

        }
    }
}
