﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MyBlogSite.Data.Migrations
{
    public partial class Visitor : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Articles",
                keyColumn: "Id",
                keyValue: new Guid("41fde7b2-7e63-4fe9-9196-ac24765f6d28"));

            migrationBuilder.DeleteData(
                table: "Articles",
                keyColumn: "Id",
                keyValue: new Guid("d124d2d7-8f05-4b95-a0b5-2a0de1b4e381"));

            migrationBuilder.CreateTable(
                name: "Visitors",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IpAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserAgent = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Visitors", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ArticleVisitors",
                columns: table => new
                {
                    ArticleId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    VisitorId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ArticleVisitors", x => new { x.ArticleId, x.VisitorId });
                    table.ForeignKey(
                        name: "FK_ArticleVisitors_Articles_ArticleId",
                        column: x => x.ArticleId,
                        principalTable: "Articles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ArticleVisitors_Visitors_VisitorId",
                        column: x => x.VisitorId,
                        principalTable: "Visitors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Articles",
                columns: new[] { "Id", "CategoryId", "Content", "CreatedBy", "CreatedDate", "DeleteDate", "DeletedBy", "ImageId", "IsDeleted", "ModifedDate", "ModifiedBy", "Title", "UserId", "ViewCount" },
                values: new object[,]
                {
                    { new Guid("6108a93d-ca69-4f8a-af29-d4eae0eff5e6"), new Guid("1eaf4102-5606-44ab-b75c-888e20f57cc4"), "Mertcan Deneme Makalesi Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", "Mertcan Asil", new DateTime(2024, 1, 28, 16, 48, 38, 81, DateTimeKind.Local).AddTicks(2839), null, null, new Guid("56910397-a84a-4d53-af36-b31abde1da55"), false, null, null, "Mertcan Makale", new Guid("4bf2f8d0-f80f-488c-9c70-290d91e06dcc"), 15 },
                    { new Guid("80a252bd-abde-44fe-8457-528aba22c405"), new Guid("98c6e945-f9e9-4141-a423-59fa1cbe51d3"), "Asil Deneme Makalesi 2 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", "Kara Davut", new DateTime(2024, 1, 28, 16, 48, 38, 81, DateTimeKind.Local).AddTicks(2878), null, null, new Guid("77e2d3f6-b7bf-4549-b7e2-7673d57586d6"), false, null, null, "Asil Makale", new Guid("2862ce3e-63e2-480c-8f2a-1f58badf318b"), 15 }
                });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("1eaf4102-5606-44ab-b75c-888e20f57cc4"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 16, 48, 38, 81, DateTimeKind.Local).AddTicks(5148));

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("98c6e945-f9e9-4141-a423-59fa1cbe51d3"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 16, 48, 38, 81, DateTimeKind.Local).AddTicks(5153));

            migrationBuilder.UpdateData(
                table: "Images",
                keyColumn: "Id",
                keyValue: new Guid("56910397-a84a-4d53-af36-b31abde1da55"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 16, 48, 38, 81, DateTimeKind.Local).AddTicks(5326));

            migrationBuilder.UpdateData(
                table: "Images",
                keyColumn: "Id",
                keyValue: new Guid("77e2d3f6-b7bf-4549-b7e2-7673d57586d6"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 16, 48, 38, 81, DateTimeKind.Local).AddTicks(5331));

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("0570beb7-d8eb-44ec-b687-6f54fdd6a28b"),
                column: "ConcurrencyStamp",
                value: "2bd04232-d5d0-4e7a-87c0-419bc9992886");

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("3b484b41-4e1b-4d7e-a4b6-0e914a926af8"),
                column: "ConcurrencyStamp",
                value: "c4a9881a-43c0-4dfb-8121-612d5e77a0ba");

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("81194495-c625-4d58-b5ab-68bc16276d12"),
                column: "ConcurrencyStamp",
                value: "7dd5c307-5f40-4842-88f6-2408704cb775");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("2862ce3e-63e2-480c-8f2a-1f58badf318b"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "dae44050-c2b6-450e-adee-7b290c882076", "AQAAAAEAACcQAAAAEBejDxul2/onKE1+olbsxci6Y67h9rB5+/H0O18ldBgnlF3H/V0JeZA3QlbkuD5lmw==", "19a47915-4a98-4dc1-9678-7e42a477e0e8" });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("4bf2f8d0-f80f-488c-9c70-290d91e06dcc"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "43b22cf5-3fcb-4278-9f6c-44b7ab747d1b", "AQAAAAEAACcQAAAAENEvJl8lki4g/zk8Hd8muxPf5hyu3t+I+db85yLu7/7NESemWucoxHat689QYMoKEQ==", "50d4ec29-202c-49fa-b1ef-9ceab8bce6ca" });

            migrationBuilder.CreateIndex(
                name: "IX_ArticleVisitors_VisitorId",
                table: "ArticleVisitors",
                column: "VisitorId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ArticleVisitors");

            migrationBuilder.DropTable(
                name: "Visitors");

            migrationBuilder.DeleteData(
                table: "Articles",
                keyColumn: "Id",
                keyValue: new Guid("6108a93d-ca69-4f8a-af29-d4eae0eff5e6"));

            migrationBuilder.DeleteData(
                table: "Articles",
                keyColumn: "Id",
                keyValue: new Guid("80a252bd-abde-44fe-8457-528aba22c405"));

            migrationBuilder.InsertData(
                table: "Articles",
                columns: new[] { "Id", "CategoryId", "Content", "CreatedBy", "CreatedDate", "DeleteDate", "DeletedBy", "ImageId", "IsDeleted", "ModifedDate", "ModifiedBy", "Title", "UserId", "ViewCount" },
                values: new object[,]
                {
                    { new Guid("41fde7b2-7e63-4fe9-9196-ac24765f6d28"), new Guid("98c6e945-f9e9-4141-a423-59fa1cbe51d3"), "Asil Deneme Makalesi 2 Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", "Kara Davut", new DateTime(2024, 1, 28, 2, 5, 23, 71, DateTimeKind.Local).AddTicks(8916), null, null, new Guid("77e2d3f6-b7bf-4549-b7e2-7673d57586d6"), false, null, null, "Asil Makale", new Guid("2862ce3e-63e2-480c-8f2a-1f58badf318b"), 15 },
                    { new Guid("d124d2d7-8f05-4b95-a0b5-2a0de1b4e381"), new Guid("1eaf4102-5606-44ab-b75c-888e20f57cc4"), "Mertcan Deneme Makalesi Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.", "Mertcan Asil", new DateTime(2024, 1, 28, 2, 5, 23, 71, DateTimeKind.Local).AddTicks(8906), null, null, new Guid("56910397-a84a-4d53-af36-b31abde1da55"), false, null, null, "Mertcan Makale", new Guid("4bf2f8d0-f80f-488c-9c70-290d91e06dcc"), 15 }
                });

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("1eaf4102-5606-44ab-b75c-888e20f57cc4"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 2, 5, 23, 71, DateTimeKind.Local).AddTicks(9195));

            migrationBuilder.UpdateData(
                table: "Categories",
                keyColumn: "Id",
                keyValue: new Guid("98c6e945-f9e9-4141-a423-59fa1cbe51d3"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 2, 5, 23, 71, DateTimeKind.Local).AddTicks(9199));

            migrationBuilder.UpdateData(
                table: "Images",
                keyColumn: "Id",
                keyValue: new Guid("56910397-a84a-4d53-af36-b31abde1da55"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 2, 5, 23, 71, DateTimeKind.Local).AddTicks(9354));

            migrationBuilder.UpdateData(
                table: "Images",
                keyColumn: "Id",
                keyValue: new Guid("77e2d3f6-b7bf-4549-b7e2-7673d57586d6"),
                column: "CreatedDate",
                value: new DateTime(2024, 1, 28, 2, 5, 23, 71, DateTimeKind.Local).AddTicks(9438));

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("0570beb7-d8eb-44ec-b687-6f54fdd6a28b"),
                column: "ConcurrencyStamp",
                value: "f44c75af-29d1-4a2d-ae96-c5a6eb6e8d6b");

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("3b484b41-4e1b-4d7e-a4b6-0e914a926af8"),
                column: "ConcurrencyStamp",
                value: "5c05f564-5ae4-48cd-a2c4-6a85698b9628");

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "Id",
                keyValue: new Guid("81194495-c625-4d58-b5ab-68bc16276d12"),
                column: "ConcurrencyStamp",
                value: "2efab6c5-e25c-41eb-9cce-1720678bd501");

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("2862ce3e-63e2-480c-8f2a-1f58badf318b"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "e1942378-fbea-4be1-8fa7-d05ffb286bae", "AQAAAAEAACcQAAAAED0f7tqJibI2Xp6BJkIWxUCMKrrJFeFzUiLQefZqsZeDPQFqimepOyUgoRtFHqJWeA==", "e3f429f8-0b23-4963-8e2b-55a3f31e99c9" });

            migrationBuilder.UpdateData(
                table: "Users",
                keyColumn: "Id",
                keyValue: new Guid("4bf2f8d0-f80f-488c-9c70-290d91e06dcc"),
                columns: new[] { "ConcurrencyStamp", "PasswordHash", "SecurityStamp" },
                values: new object[] { "3de7caa2-d6a0-47a3-a214-baaa7c9444d1", "AQAAAAEAACcQAAAAEM02+puMfWoW6xfaIDg1JLMDqatsl/2yP8ShBuy5D3AS0yvMQyF4/rCUeEHEnG5l1w==", "58cf9f79-f608-4e9d-a058-83b932faf2b1" });
        }
    }
}
