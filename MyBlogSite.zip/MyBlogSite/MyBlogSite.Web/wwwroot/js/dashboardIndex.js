﻿


$(document).ready(function () {
    var totalArticleCountUrl = app.Urls.totalArticleCountUrl;
    var totalCategoryCountUrl = app.Urls.totalCategoryCountUrl;
    var totalUserCountUrl = app.Urls.totalUserCountUrl;

    $.ajax({
        type: "GET",
        url: totalArticleCountUrl,
        dataType: "json",
        success: function (data) {
            $("h3#totalArticleCount").append(data);
        },
        error: function () {
            toastr.error("Makale Analizleri yüklenirken hata oluştu", "Hata");
        }

    });
    $.ajax({
        type: "GET",
        url: totalCategoryCountUrl,
        dataType: "json",
        success: function (data) {
            $("h3#totalCategoryCount").append(data);
        },
        error: function () {
            toastr.error("Kategori Analizleri yüklenirken hata oluştu", "Hata");
        }

    });
    $.ajax({
        type: "GET",
        url: totalUserCountUrl,
        dataType: "json",
        success: function (data) {
            $("h3#totalUserCount").append(data);
        },
        error: function () {
            toastr.error("Kullanıcılar Analizleri yüklenirken hata oluştu", "Hata");
        }

    });


});