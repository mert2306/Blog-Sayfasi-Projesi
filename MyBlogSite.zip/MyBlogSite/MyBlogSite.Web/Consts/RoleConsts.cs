﻿namespace MyBlogSite.Web.Consts
{
    public class RoleConsts
    {
        public const string Superadmin = "Superadmin";
        public const string Admin = "Admin";
        public const string User = "User";


    }
}
