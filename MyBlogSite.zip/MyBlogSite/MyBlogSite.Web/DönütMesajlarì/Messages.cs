﻿namespace MyBlogSite.Web.DönütMesajları
{
    public static class Messages
    {
        public static class Article
        {
            public static string Add(string articleTitle)
            {
                return $"{articleTitle} başlıklı Makale Başarılı Bir Şekilde Eklendi!";
            }
            public static string Update(string articleTitle)
            {
                return $"{articleTitle} başlıklı Makale Başarılı Bir Şekilde Güncellendi!";
            }
            public static string Delete(string articleTitle)
            {
                return $"{articleTitle} başlıklı Makale Başarılı Bir Şekilde Silindi!";
            }
            public static string UndoDelete(string articleTitle)
            {
                return $"{articleTitle} başlıklı Makale Başarılı Bir Şekilde Geri Getirildi!";
            }
        }
        public static class Category
        {
            public static string Add(string categoryName)
            {
                return $"{categoryName} başlıklı kategori Başarılı Bir Şekilde Eklendi!";
            }
            public static string Update(string categoryName)
            {
                return $"{categoryName} başlıklı kategori Başarılı Bir Şekilde Güncellendi!";
            }
            public static string Delete(string categoryName)
            {
                return $"{categoryName} başlıklı kategori Başarılı Bir Şekilde Silindi!";
            }
            public static string UndoDelete(string categoryName)
            {
                return $"{categoryName} başlıklı Kategori Başarılı Bir Şekilde Geri Getirildi!";
            }
        }
        public static class User
        {
            public static string Add(string userName)
            {
                return $"{userName}  İsimli Kullanıcı Başarılı Bir Şekilde Eklendi!";
            }
            public static string Update(string userName)
            {
                return $"{userName} İsimli Kullanıcı Başarılı Bir Şekilde Güncellendi!";
            }
            public static string Delete(string userName)
            {
                return $"{userName} İsimli Kullanıcı Başarılı Bir Şekilde Silindi!";
            }
        }

    }
}
