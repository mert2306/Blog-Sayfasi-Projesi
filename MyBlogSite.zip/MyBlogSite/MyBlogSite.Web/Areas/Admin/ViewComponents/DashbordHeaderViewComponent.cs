﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Users;

namespace MyBlogSite.Web.Areas.Admin.ViewComponents
{
    public class DashbordHeaderViewComponent : ViewComponent
    {
        private readonly UserManager<AppUser> userManager;
        private readonly IMapper mapper;

        public DashbordHeaderViewComponent(UserManager<AppUser> userManager, IMapper mapper)
        {
            this.userManager = userManager;
            this.mapper = mapper;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var loggedInUser = await userManager.GetUserAsync(HttpContext.User);
            var map = mapper.Map<UserViewModel>(loggedInUser);
            
            var role = string.Join("", await userManager.GetRolesAsync(loggedInUser));

            map.Role = role;

            return View(map);
        }

    }
}
