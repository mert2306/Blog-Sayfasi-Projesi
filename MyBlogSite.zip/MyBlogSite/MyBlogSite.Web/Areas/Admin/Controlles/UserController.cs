﻿using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Users;
using MyBlogSite.Service.Extensions;
using MyBlogSite.Service.Services.Abstractions;
using MyBlogSite.Web.Consts;
using MyBlogSite.Web.DönütMesajları;
using NToastNotify;

namespace MyBlogSite.Web.Areas.Admin.Controlles
{
    [Area("Admin")]
    public class UserController : Controller
    {
        private readonly IUserService userService;
        private readonly IValidator<AppUser> validator;
        private readonly IMapper mapper;
        private readonly IToastNotification toastNotification;

        public UserController( IUserService userService, IValidator<AppUser> validator, IToastNotification toastNotification, IMapper mapper)
        {
            this.userService = userService;
            this.validator = validator;
            this.mapper = mapper;
            this.toastNotification = toastNotification;
        }


        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]
        public async Task<IActionResult> Index()
        {
            var result = await userService.GetAllUserWithRoleAsync();
            return View(result);
        }
       

        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]
        public async Task<IActionResult> Add()
        {
            var roles = await userService.GetAllRolesAsync();
            return View(new UserAddViewModel { Roles = roles });
        }


        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]
        public async Task<IActionResult> Add(UserAddViewModel userAddViewModel)
        {
            var map = mapper.Map<AppUser>(userAddViewModel);
            var validation = await validator.ValidateAsync(map);
            var roles = await userService.GetAllRolesAsync();

            if (ModelState.IsValid)
            {
                var result = await userService.CreateUserAsync(userAddViewModel);
                if (result.Succeeded)
                {
                    toastNotification.AddSuccessToastMessage(Messages.User.Add(userAddViewModel.Email), new ToastrOptions { Title = "Aramıza Hoşgeldin!" });
                    return RedirectToAction("Index", "User", new { Area = "Admin" });
                }
                else
                {
                    result.AddToIdentityModelState(this.ModelState);
                    validation.AddToModelState(this.ModelState);
                    return View(new UserAddViewModel { Roles = roles });
                }
            }
            return View(new UserAddViewModel { Roles = roles });
        }

        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}")]

        public async Task<IActionResult> Update(Guid userId)
        {
            var user = await userService.GetAppUserByIdAsync(userId);
            var roles = await userService.GetAllRolesAsync();

            var map = mapper.Map<UserUpdateViewModel>(user);
            map.Roles = roles;
            return View(map);
        }
        
        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}")]
        public async Task<IActionResult> Update(UserUpdateViewModel userUpdateViewModel)
        {
            var user = await userService.GetAppUserByIdAsync(userUpdateViewModel.Id);
            if (user != null)
            {
                var roles = await userService.GetAllRolesAsync();
                if (ModelState.IsValid)
                {
                    var map = mapper.Map(userUpdateViewModel, user);
                    var validation = await validator.ValidateAsync(map);
                    if (validation.IsValid)
                    {
                        user.UserName = userUpdateViewModel.Email;
                        user.SecurityStamp = Guid.NewGuid().ToString();
                        var result = await userService.UpdateUserAsync(userUpdateViewModel);
                        if (result.Succeeded)
                        {
                            toastNotification.AddInfoToastMessage(Messages.User.Update(userUpdateViewModel.Email), new ToastrOptions { Title = "Yeniden Aramıza Hoşgeldin!" });
                            return RedirectToAction("Index", "User", new { Area = "Admin" });
                        }
                        else
                        {
                            result.AddToIdentityModelState(this.ModelState);
                            return View(new UserUpdateViewModel { Roles = roles });
                        }
                    }
                    else
                    {
                        validation.AddToModelState(this.ModelState);
                        return View(new UserUpdateViewModel { Roles = roles });
                    }
                }
            }
            return NotFound();
        }


        [Authorize(Roles = $"{RoleConsts.Superadmin}")]
        public async Task<IActionResult> Delete(Guid userId)
        {
            

            var result = await userService.DeleteUserAsync(userId);

            if (result.identityResult.Succeeded)
            {
                toastNotification.AddErrorToastMessage(Messages.User.Delete(result.email), new ToastrOptions { Title = "Güle güle👋 !!" });
                return RedirectToAction("Index", "User", new { Area = "Admin" });
            }
            else
            {
                    result.identityResult.AddToIdentityModelState(this.ModelState);
            }
            return NotFound();
        }
        
        
        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            var profile = await userService.GetUserProfileAsync();
            return View(profile);
        }


        [HttpPost]
        public async Task<IActionResult> Profile(UserProfileViewModel userProfileViewModel)
        {

            if (ModelState.IsValid)
            {
               var result = await userService.UserProfileUpdateAsync(userProfileViewModel);
                if (result)
                {
                    toastNotification.AddSuccessToastMessage("Profil güncelleme işlemi başarılı", new ToastrOptions { Title = "yenilendin👋 !!" });
                    return RedirectToAction("Index", "Home", new { Area = "Admin" });

                }
                else
                {
                    var profile = await userService.GetUserProfileAsync();
                    toastNotification.AddErrorToastMessage("Profil güncelleme işlemi başarısız", new ToastrOptions { Title = "yenilenemedin !!" });
                    return View(profile);
                }
               
            }
            else
            {
               return NotFound();
            }

        }

    }
}
