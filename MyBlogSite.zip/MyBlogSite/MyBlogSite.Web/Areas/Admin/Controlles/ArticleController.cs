﻿using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Articles;
using MyBlogSite.Service.Extensions;
using MyBlogSite.Service.Services.Abstractions;
using MyBlogSite.Web.Consts;
using MyBlogSite.Web.DönütMesajları;
using NToastNotify;

namespace MyBlogSite.Web.Areas.Admin.Controlles
{
    [Area("Admin")]
    public class ArticleController : Controller
    {
        private readonly IArticleService articleService;
        private readonly ICategoryService categoryService;
        private readonly IMapper mapper;
        private readonly IValidator<Article> validator;
        private readonly IToastNotification toastNotification;


        public ArticleController(IArticleService articleService, ICategoryService categoryService, IMapper mapper, IValidator<Article> validator, IToastNotification toastNotification)
        {
            this.articleService = articleService;
            this.categoryService = categoryService;
            this.mapper = mapper;
            this.validator = validator;
            this.toastNotification = toastNotification;
        }
        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}, {RoleConsts.User}")]
        public async Task<IActionResult> Index()
        {
            var articles = await articleService.GetAllArticlesWithCategoryNonDeletedAsync();

            return View(articles);
        }
        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]
        public async Task<IActionResult> DeletedArticle()
        {
            var articles = await articleService.GetAllArticlesWithCategoryDeletedAsync();

            return View(articles);
        }
        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin},{RoleConsts.User}")]
        public async Task<IActionResult> Add()
        {
            var categories = await categoryService.GetAllCategoriesNonDeleted();
            return View(new ArticleAddViewModel { Categories = categories });
        }

        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin},{RoleConsts.User}")]
        public async Task<IActionResult> Add(ArticleAddViewModel articleAddViewModel)
        {
            var map = mapper.Map<Article>(articleAddViewModel);

            var result = await validator.ValidateAsync(map);

            if (result.IsValid)
            {

                await articleService.CreateArticleAsync(articleAddViewModel);
                toastNotification.AddSuccessToastMessage(Messages.Article.Add(articleAddViewModel.Title), new ToastrOptions { Title = "Güzel Makale hee!" });
                return RedirectToAction("Index", "Article", new { Area = "Admin" });

            }
            else
            {
                result.AddToModelState(this.ModelState);
                var categories = await categoryService.GetAllCategoriesNonDeleted();
                return View(new ArticleAddViewModel { Categories = categories });
            }



        }

        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]
        public async Task<IActionResult> Update(Guid articleId)
        {
            var article = await articleService.GetArticleWithCategoryNonDeletedAsync(articleId);
            var categories = await categoryService.GetAllCategoriesNonDeleted();

            var articleUpdateViewModel = mapper.Map<ArticleUpdateViewModel>(article);
            articleUpdateViewModel.Categories = categories;

            return View(articleUpdateViewModel);

        }
        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]
        public async Task<IActionResult> Update(ArticleUpdateViewModel articleUpdateViewModel)
        {

            var map = mapper.Map<Article>(articleUpdateViewModel);
            var result = await validator.ValidateAsync(map);

            if (result.IsValid)
            {

                var title = await articleService.UpdateArticleAsync(articleUpdateViewModel);
                toastNotification.AddInfoToastMessage(Messages.Article.Update(title), new ToastrOptions { Title = "Güzel Yeniledin!" });
                return RedirectToAction("Index", "Article", new { Area = "Admin" });
            }
            else
            {
                result.AddToModelState(this.ModelState);
            }


            var categories = await categoryService.GetAllCategoriesNonDeleted();
            articleUpdateViewModel.Categories = categories;
            return View(articleUpdateViewModel);

        }
        [Authorize(Roles = $"{RoleConsts.Superadmin}")]
        public async Task<IActionResult> Delete(Guid articleId)
        {

            var title = await articleService.SafeDeleteArticleAsync(articleId);
            toastNotification.AddErrorToastMessage(Messages.Article.Delete(title), new ToastrOptions { Title = "Yazık oldu Güzelim Makaleye!" });


            return RedirectToAction("Index", "Article", new { Area = "Admin" });

        }
        [Authorize(Roles = $"{RoleConsts.Superadmin}")]
        public async Task<IActionResult> UndoDelete(Guid articleId)
        {

            var title = await articleService.UndoSafeDeleteArticleAsync(articleId);
            toastNotification.AddErrorToastMessage(Messages.Article.UndoDelete(title), new ToastrOptions { Title = "Seni Yeniden aramızda Görmek Ne Güzel!" });


            return RedirectToAction("Index", "Article", new { Area = "Admin" });

        }

    }
}
