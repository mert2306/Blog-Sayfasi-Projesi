﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Service.Services.Abstractions;
using System.Globalization;

namespace MyBlogSite.Web.Areas.Admin.Controlles
{
    [Area("Admin")]
    [Authorize]

    public class HomeController : Controller

    {
        private readonly IArticleService articleService;
        private readonly IDashbordService dashbordService;

        public HomeController(IArticleService articleService, IDashbordService dashbordService)
        {
            this.articleService = articleService;
            this.dashbordService = dashbordService;
        }
        public async Task<IActionResult> Index()

        {
            var articles = await articleService.GetAllArticlesWithCategoryNonDeletedAsync();


            return View(articles);
        }

        [HttpGet]
        public async Task<IActionResult> TotalArticleCount()

        {
            var mSayac = await dashbordService.GetTotalArticleCount();
            return Json(mSayac);

        } 
        [HttpGet]
        public async Task<IActionResult> TotalCategoryCount()

        {
            var kSayac = await dashbordService.GetTotalCategoryCount();
            return Json(kSayac);

        }
        [HttpGet]
        public async Task<IActionResult> TotalUserCount()

        {
            var kullaniciSayac = await dashbordService.GetTotalUserCount();
            return Json(kullaniciSayac);

        }

    }
}
