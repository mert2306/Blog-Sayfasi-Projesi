﻿using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Articles;
using MyBlogSite.Entity.Viewmodels.Categories;
using MyBlogSite.Service.Extensions;
using MyBlogSite.Service.Services.Abstractions;
using MyBlogSite.Service.Services.Concrete;
using MyBlogSite.Web.Consts;
using MyBlogSite.Web.DönütMesajları;
using NToastNotify;

namespace MyBlogSite.Web.Areas.Admin.Controlles
{
    [Area("Admin")]
    public class CategoryController : Controller
    {
        private readonly ICategoryService categoryService;
        private readonly IValidator<Category> validator;
        private readonly IMapper mapper;
        private readonly IToastNotification toastNotification;

        public CategoryController(ICategoryService categoryService, IValidator<Category> validator, IMapper mapper, IToastNotification toastNotification)
        {
            this.categoryService = categoryService;
            this.validator = validator;
            this.mapper = mapper;
            this.toastNotification = toastNotification;
        }
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}, {RoleConsts.User}")]

        public async Task<IActionResult> Index()
        {
            var categories = await categoryService.GetAllCategoriesNonDeleted();
            return View(categories);
        }
        public async Task<IActionResult> DeletedCategory()
        {
            var categories = await categoryService.GetAllCategoriesDeleted();
            return View(categories);
        }

        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin},{RoleConsts.User}")]
        public IActionResult Add()
        {
            return View();
        }
        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin},{RoleConsts.User}")]

        public async Task<IActionResult> Add(CategoryAddViewModel categoryAddViewModel)
        {
            var map = mapper.Map<Category>(categoryAddViewModel);
            var result = await validator.ValidateAsync(map);

            if (result.IsValid)
            {

                await categoryService.CreateCategoryAsync(categoryAddViewModel);
                toastNotification.AddSuccessToastMessage(Messages.Category.Add(categoryAddViewModel.Name), new ToastrOptions { Title = "Güzel Kategori hee!" });
                return RedirectToAction("Index", "Category", new { Area = "Admin" });

            }


            result.AddToModelState(this.ModelState);

            return View();

        }
        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin},{RoleConsts.User}")]

        public async Task<IActionResult> AddWithAjax([FromBody] CategoryAddViewModel categoryAddViewModel)
        {
            var map = mapper.Map<Category>(categoryAddViewModel);
            var result = await validator.ValidateAsync(map);

            if (result.IsValid)
            {

                await categoryService.CreateCategoryAsync(categoryAddViewModel);
                toastNotification.AddSuccessToastMessage(Messages.Category.Add(categoryAddViewModel.Name), new ToastrOptions { Title = "Güzel Kategori hee!" });

                return Json(Messages.Category.Add(categoryAddViewModel.Name));

            }
            else
            {
                toastNotification.AddErrorToastMessage(result.Errors.First().ErrorMessage, new ToastrOptions { Title = "Ekleyemedin ama!" });
                return Json(result.Errors.First().ErrorMessage);
            }


        }



        [HttpGet]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]

        public async Task<IActionResult> Update(Guid categoryId)
        {
            var category = await categoryService.GetCategoryByGuid(categoryId);
            var map = mapper.Map<Category, CategoryUpdateViewModel>(category);
            return View(map);
        }
        [HttpPost]
        [Authorize(Roles = $"{RoleConsts.Superadmin}, {RoleConsts.Admin}")]

        public async Task<IActionResult> Update(CategoryUpdateViewModel categoryUpdateViewModel)
        {
            var map = mapper.Map<Category>(categoryUpdateViewModel);
            var result = await validator.ValidateAsync(map);

            if (result.IsValid)
            {
                var name = await categoryService.UpdateCategoryAsync(categoryUpdateViewModel);
                toastNotification.AddSuccessToastMessage(Messages.Category.Update(name), new ToastrOptions { Title = "Güzel yenilendi!" });
                return RedirectToAction("Index", "Category", new { Area = "Admin" });
            }
            else
            {
                result.AddToModelState(this.ModelState);
            }

            return View(categoryUpdateViewModel);
        }
        [Authorize(Roles = $"{RoleConsts.Superadmin},")]

        public async Task<IActionResult> Delete(Guid categoryId)
        {

            var name = await categoryService.SafeDeleteCategoryAsync(categoryId);
            toastNotification.AddErrorToastMessage(Messages.Category.Delete(name), new ToastrOptions { Title = "Yazık oldu Güzelim Kategoriye!" });


            return RedirectToAction("Index", "Category", new { Area = "Admin" });

        }
        
        [Authorize(Roles = $"{RoleConsts.Superadmin}")]

        public async Task<IActionResult> UndoDelete(Guid categoryId)
        {

            var name = await categoryService.UndoDeleteCategoryAsync(categoryId);
            toastNotification.AddErrorToastMessage(Messages.Category.UndoDelete(name), new ToastrOptions { Title = "Kategorin geri geldi hadi yine iyisin!" });


            return RedirectToAction("Index", "Category", new { Area = "Admin" });

        }

    }
}

