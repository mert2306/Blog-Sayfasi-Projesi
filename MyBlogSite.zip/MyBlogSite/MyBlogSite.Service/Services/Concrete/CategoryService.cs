﻿using AutoMapper;
using Microsoft.AspNetCore.Http;
using MyBlogSite.Data.UnitOfWorks;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Articles;
using MyBlogSite.Entity.Viewmodels.Categories;
using MyBlogSite.Service.Extensions;
using MyBlogSite.Service.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.Services.Concrete
{
    public class CategoryService : ICategoryService

    {
        private readonly IUnitOfWork unitOfWork;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ClaimsPrincipal Kullanici;

        public CategoryService(IUnitOfWork unitOfWork, IMapper mapper, IHttpContextAccessor httpContextAccessor)
        {
            this.unitOfWork = unitOfWork;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
            Kullanici = httpContextAccessor.HttpContext.User;
        }
        public async Task<List<CategoryViewModel>> GetAllCategoriesNonDeleted()
        {
            var categories = await unitOfWork.GetRepository<Category>().GetAllAsync(x => !x.IsDeleted);
            var map = mapper.Map<List<CategoryViewModel>>(categories);
            return map;
        }
        public async Task<List<CategoryViewModel>> GetAllCategoriesNonDeletedTake()
        {
            var categories = await unitOfWork.GetRepository<Category>().GetAllAsync(x => !x.IsDeleted);
            var map = mapper.Map<List<CategoryViewModel>>(categories);
            
            return map.Take(24).ToList();
        }

        public async Task CreateCategoryAsync(CategoryAddViewModel categoryAddViewModel)
        {
            
            var userEmail = Kullanici.GetLoggedInEmail();
            Category category = new(categoryAddViewModel.Name, userEmail);
            await unitOfWork.GetRepository<Category>().AddAsync(category);
            await unitOfWork.SaveAsync();

        }
        public async Task<Category> GetCategoryByGuid(Guid id)
        {
            var category = await unitOfWork.GetRepository<Category>().GetByGuidAsync(id);
            return category;

        }
        public async Task<string> UpdateCategoryAsync(CategoryUpdateViewModel categoryUpdateViewModel)
        {

            var userEmail = Kullanici.GetLoggedInEmail();
            var category = await unitOfWork.GetRepository<Category>().GetAsync(x => !x.IsDeleted && x.Id == categoryUpdateViewModel.Id);
          
            category.Name = categoryUpdateViewModel.Name;
            category.ModifiedBy = userEmail;
            category.ModifedDate = DateTime.Now;
            

            await unitOfWork.GetRepository<Category>().UpdateAsync(category);
            await unitOfWork.SaveAsync();
            return category.Name;

        }
        public async Task<string> SafeDeleteCategoryAsync(Guid categoryId)
        {
            var userEmail = Kullanici.GetLoggedInEmail();
            var category = await unitOfWork.GetRepository<Category>().GetByGuidAsync(categoryId);

            category.IsDeleted = true;
            category.DeleteDate = DateTime.Now;
            category.DeletedBy = userEmail;
            await unitOfWork.GetRepository<Category>().UpdateAsync(category);
            await unitOfWork.SaveAsync();

            return category.Name;
        }

        public async Task<List<CategoryViewModel>> GetAllCategoriesDeleted()
        {
            var categories = await unitOfWork.GetRepository<Category>().GetAllAsync(x => x.IsDeleted);
            var map = mapper.Map<List<CategoryViewModel>>(categories);
            return map;
        }

        public async Task<string> UndoDeleteCategoryAsync(Guid categoryId)
        {
            var userEmail = Kullanici.GetLoggedInEmail();
            var category = await unitOfWork.GetRepository<Category>().GetByGuidAsync(categoryId);

            category.IsDeleted = false;
            category.DeleteDate = null;
            category.DeletedBy = null;
            await unitOfWork.GetRepository<Category>().UpdateAsync(category);
            await unitOfWork.SaveAsync();

            return category.Name;
        }

   
    }
}
