﻿using MyBlogSite.Data.UnitOfWorks;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Service.Services.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.Services.Concrete
{
    public class DashbordService : IDashbordService
    {
        private readonly IUnitOfWork unitOfWork;

        public DashbordService(IUnitOfWork unitOfWork)
        {
            this.unitOfWork = unitOfWork;
        }

      
        public async Task<int> GetTotalArticleCount()
        {
            var makaleSayac = await unitOfWork.GetRepository<Article>().CountAsync();
            return makaleSayac;

        }
        public async Task<int> GetTotalCategoryCount()
        {
            var kategoriSayac = await unitOfWork.GetRepository<Category>().CountAsync();
            return kategoriSayac;

        } 
        public async Task<int> GetTotalUserCount()
        {
            var kullaniciSayac = await unitOfWork.GetRepository<AppUser>().CountAsync();
            return kullaniciSayac;

        }


    }
}
