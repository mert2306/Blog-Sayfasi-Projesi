﻿using Microsoft.AspNetCore.Mvc;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Categories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.Services.Abstractions
{
    public interface ICategoryService
    {
        Task<List<CategoryViewModel>> GetAllCategoriesNonDeleted();
        Task<List<CategoryViewModel>> GetAllCategoriesNonDeletedTake();
        Task<List<CategoryViewModel>> GetAllCategoriesDeleted();
        Task CreateCategoryAsync(CategoryAddViewModel categoryAddViewModel);
        Task<Category> GetCategoryByGuid(Guid id);
        Task<string> UpdateCategoryAsync(CategoryUpdateViewModel categoryUpdateViewModel);

        Task<string> SafeDeleteCategoryAsync(Guid categoryId);
        Task<string> UndoDeleteCategoryAsync(Guid categoryId);
    }
}
