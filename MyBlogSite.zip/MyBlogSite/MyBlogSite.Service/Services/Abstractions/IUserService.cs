﻿using Microsoft.AspNetCore.Identity;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.Services.Abstractions
{
    public interface IUserService
    {
        Task<List<UserViewModel>> GetAllUserWithRoleAsync();
        Task<List<AppRole>> GetAllRolesAsync();
        Task<IdentityResult> CreateUserAsync(UserAddViewModel userAddViewModel);
        Task<IdentityResult> UpdateUserAsync(UserUpdateViewModel userUpdateViewModel);
        Task<(IdentityResult identityResult, string? email)> DeleteUserAsync(Guid userId);
        Task<AppUser> GetAppUserByIdAsync (Guid userId);
        Task<string> GetUserRoleAsync(AppUser user);
        Task<UserProfileViewModel> GetUserProfileAsync();
        Task<bool> UserProfileUpdateAsync(UserProfileViewModel userProfileViewModel);
    }
}
