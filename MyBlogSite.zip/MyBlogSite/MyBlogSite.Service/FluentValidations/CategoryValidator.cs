﻿using FluentValidation;
using MyBlogSite.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.FluentValidations
{
    public class CategoryValidator : AbstractValidator<Category>

    {
        public CategoryValidator()
        {
            RuleFor(a => a.Name)
                .NotEmpty()
                .NotNull()
                .Length(3, 200)
                .WithName("Kategori İsmi");
        }
    }
}
