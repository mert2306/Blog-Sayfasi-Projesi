﻿using FluentValidation;
using MyBlogSite.Entity.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.FluentValidations
{
    public class ArticleValidator : AbstractValidator<Article>
    {
        public ArticleValidator()
        {
            RuleFor(a => a.Title)
                .NotEmpty()
                .NotNull()
                .Length(3, 200)
                .WithName("Başlık");
            RuleFor(a => a.Content)
                .NotEmpty()
                .NotNull()
                .Length(3, 1000000)
                .WithName("İçerik");
            
        }



    }
}
