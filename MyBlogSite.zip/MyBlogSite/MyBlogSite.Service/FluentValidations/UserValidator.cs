﻿using FluentValidation;
using MyBlogSite.Entity.Entities;

namespace MyBlogSite.Service.FluentValidations
{
    public class UserValidator : AbstractValidator<AppUser>
    {

        public UserValidator()
        {
            RuleFor(x => x.Firstname)
            .NotEmpty()
            .Length(1, 50)
            .WithName("İsim");
            RuleFor(x => x.LastName)
             .NotEmpty()
             .Length(1, 50)
             .WithName("Soyisim"); 
            RuleFor(x => x.PhoneNumber)
             .NotEmpty()
             .MinimumLength(11)
             .WithName("Telefon Numarası");



        }
    }
}
