﻿using Microsoft.AspNetCore.Http;
using MyBlogSite.Entity.Enums;
using MyBlogSite.Entity.Viewmodels.Images;

namespace MyBlogSite.Service.Helpers.Images
{
    public interface IImageHelper
    {
        Task<ImageUploadedViewModel> Upload(string name, IFormFile imageFile,ImageType imageType ,string? folderName =null);
        void Delete(string imageName);
    }
}
