﻿using AutoMapper;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Users;

namespace MyBlogSite.Service.AutoMapper.Users
{
    public class UserProfile : Profile
    {
        public UserProfile()
        {
            CreateMap<AppUser, UserViewModel>().ReverseMap();
            CreateMap<AppUser, UserAddViewModel>().ReverseMap();
            CreateMap<AppUser, UserUpdateViewModel>().ReverseMap();
            CreateMap<AppUser, UserProfileViewModel>().ReverseMap();

      
        }
    }
}
