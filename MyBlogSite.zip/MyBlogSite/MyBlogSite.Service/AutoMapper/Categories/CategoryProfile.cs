﻿using AutoMapper;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Categories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyBlogSite.Service.AutoMapper.Categories
{
    public class CategoryProfile : Profile
    {
        public CategoryProfile()
        {
            CreateMap<CategoryViewModel, Category>().ReverseMap();
            CreateMap<CategoryAddViewModel, Category>().ReverseMap();
            CreateMap<CategoryUpdateViewModel, Category>().ReverseMap();
        }
    }
}
