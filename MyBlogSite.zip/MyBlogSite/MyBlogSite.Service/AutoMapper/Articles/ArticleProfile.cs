﻿using AutoMapper;
using MyBlogSite.Entity.Entities;
using MyBlogSite.Entity.Viewmodels.Articles;

namespace MyBlogSite.Service.AutoMapper.Articles
{
    public class ArticleProfile : Profile

    {
        public ArticleProfile()
        {
            CreateMap<ArticleViewModel, Article>().ReverseMap();
            CreateMap<ArticleUpdateViewModel, Article>().ReverseMap();
            CreateMap<ArticleUpdateViewModel, ArticleViewModel>().ReverseMap();
            CreateMap<ArticleAddViewModel, Article>().ReverseMap();
        }
    }
}
